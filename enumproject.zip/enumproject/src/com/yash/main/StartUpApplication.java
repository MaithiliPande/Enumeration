package com.yash.main;
import java.util.List;
import java.util.Scanner;
import com.yash.model.Project;
import com.yash.service.ProjectService;
/**
 * This is start up class for the application.
 * @author maithili.pande
 *
 */
public class StartUpApplication {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		ProjectService service= new ProjectService();
		int choice;
		String continueChoice;
		do
		{
			System.out.println("Menu");
			System.out.println("1.Add user\n2.List user");
			System.out.println("Enter your choice:");
			choice=input.nextInt();
			switch(choice)
			{
			case 1:
				Project proj=new Project();
				System.out.println("Enter student's id:");
				int studentId=input.nextInt();
				proj.setStudentId(studentId);
				System.out.println("Enter student's name:");
				String studentName=input.next();
				proj.setStudentName(studentName);
				System.out.println("Enter student's project:");
				String studentProject=input.next();
				proj.setProject(studentProject);
				service.addStudent(proj);
				break;
			case 2:
				List<Project> studentList=service.listStudent();
				for(Project project:studentList)
				{
					System.out.println(project);
				}
				break;
			default:
					break;
			
			
			}
			System.out.println("Do you want to continue: (yes/no)");
			continueChoice=input.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		
		
		input.close();

	}

}
