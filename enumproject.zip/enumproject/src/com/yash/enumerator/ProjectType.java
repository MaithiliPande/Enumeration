package com.yash.enumerator;
/**
 * This is enumerator with name ProjectType which contains fixed set of constants like JAVA, DOTNET,PHP. It contains an abstract method.
 * @author maithili.pande
 *
 */
public enum ProjectType {
	JAVA("web applications")
	{
		@Override
		public String projectType() {
			return "JAVA";
		}
		
	},DOTNET("web applications")
	{
		@Override
		public String projectType() {
			return "DOTNET";
		}
		
	},PHP("web applications")
	{
		@Override
		public String projectType() {
			return "PHP";
		}
		
	};
	
	private String technology;
	
	private ProjectType(String tech)
	{
		this.technology=tech;
	}
	
	public abstract String projectType();
	public String getTech()
	{
		return technology;
	}
	
}
