package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.model.Project;
/**
 * This is a service class. It provides methods to add and list student's project details.
 * @author maithili.pande
 *
 */
public class ProjectService {
	private List<Project> projectRepository = new ArrayList<Project>();
	Project project =new Project();
	
	public void addStudent(Project proj)
	{
		projectRepository.add(proj);
	}
	
	public List<Project> listStudent()
	{
		return projectRepository;
	}

}
