package com.yash.model;

import com.yash.enumerator.ProjectType;
public class Project {
	private int studentId;
	private String studentName;
	private ProjectType project;
	
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public ProjectType getProject() {
		return project;
	}
	public void setProject(String project) {
		if(project.equalsIgnoreCase("java"))
		{
			this.project=ProjectType.JAVA;
		}
		else if(project.equalsIgnoreCase("dotnet"))
		{
			this.project=ProjectType.DOTNET;
		}
		else if(project.equalsIgnoreCase("php"))
		{
			this.project=ProjectType.PHP;
		}
		
	}
	
	public Project() {}
	
	
	
	@Override
	public String toString() {
		return "[Student Id:"+this.getStudentId()+" Student Name:"+this.getStudentName()+" Project:"+this.getProject()+" Type:"+this.getProject().getTech()+"]";
	}
	
	
	
	
	
	

}
