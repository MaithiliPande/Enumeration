package enumdemo;

public class EnumDemo {
	public static void main(String[] args) {
		Color color= Color.BLUE;
		System.out.println(color.ordinal());
		
		
	}

}
