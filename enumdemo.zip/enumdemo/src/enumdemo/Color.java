package enumdemo;

public enum Color {
	RED,GREEN,BLUE

};
