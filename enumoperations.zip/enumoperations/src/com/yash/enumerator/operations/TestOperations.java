package com.yash.enumerator.operations;

import java.util.Scanner;

import com.yash.enumerator.Operations;
/**
 * This is the start up class for the application.
 * @author maithili.pande
 *
 */

public class TestOperations {

	public static void main(String[] args) {
		Scanner input= new Scanner(System.in);
		System.out.println("Enter operation to perform");
		String opName = input.next();
		Operations operation= Operations.valueOf(opName.toUpperCase());
		switch(operation)
		{
		case PLUS:
			System.out.println("Enter two numbers to add:");
			int numberAdd1=input.nextInt();
			int numberAdd2=input.nextInt();
			int resultAdd=operation.getResult(numberAdd1, numberAdd2);
			System.out.println("Result: "+resultAdd);
			break;
		case MINUS:
			System.out.println("Enter two numbers to add:");
			int numberSub1=input.nextInt();
			int numberSub2=input.nextInt();
			int resultSub=operation.getResult(numberSub1, numberSub2);
			System.out.println("Result: "+resultSub);
			break;
		case TIMES:
			System.out.println("Enter two numbers to add:");
			int numberMul1=input.nextInt();
			int numberMul2=input.nextInt();
			int resultMul=operation.getResult(numberMul1, numberMul2);
			System.out.println("Result: "+resultMul);
			break;
		case DIVIDE:
			System.out.println("Enter two numbers to add:");
			int numberDiv1=input.nextInt();
			int numberDiv2=input.nextInt();
			int resultDiv=operation.getResult(numberDiv1, numberDiv2);
			System.out.println("Result: "+resultDiv);
			break;
		default:
			System.out.println("Invalid choice");
			break;
		}
		input.close();
	}

}
