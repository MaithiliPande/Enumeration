package com.yash.enumerator;
/**
 * This is enumerator with name Operations which has a fixed set of constants PLUS, MINUS, TIMES, DIVIDE. It has an abstract method.
 * @author maithili.pande
 *
 */
public enum Operations {
	PLUS("+")
	{
		@Override
		public int getResult(int num1, int num2) {
			int res= num1+num2;
			return res;
		}
	},MINUS("-")
	{
		@Override
		public int getResult(int num1, int num2) {
			int res= num1-num2;
			return res;
		}
	},TIMES("*")
		{
		@Override
		public int getResult(int num1, int num2) {
			int res= num1*num2;
			return res;
		}
		
		},DIVIDE("/")
		{
			@Override
			public int getResult(int num1, int num2) {
				int res= num1/num2;
				return res;
			}
		};

	
	private String operator;

	private Operations(String op) {
		this.operator = op;
	}
	
	public abstract int getResult(int n1, int n2);
	
	
	
	

}
