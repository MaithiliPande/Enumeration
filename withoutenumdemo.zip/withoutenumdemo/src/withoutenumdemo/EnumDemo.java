package withoutenumdemo;

public class EnumDemo {

	public static void main(String[] args) {
		Day day =new Day();
		day.setDay(10);
		System.out.println("Day is: "+day.getDay());
	

	}

}
