package withoutenumdemo;

public class Day {
	private int day;
	
	public int getDay()
	{
		return day;
	}
	
	public void setDay(int day)
	{
		this.day=day;
	}
	
	

}
