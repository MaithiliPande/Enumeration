package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.model.User;
/**
 * This is a service class which provides functionality to add and list user.
 * @author maithili.pande
 *
 */
public class UserService {
	private List<User>userRepository = new ArrayList<User>();
	User user = new User();
	
	public void addUser(User u) {
		userRepository.add(u);
	}
	
	public List<User> listUser(){
		return userRepository;
		
	}
	

}
