package com.yash.main;

import java.util.List;
import java.util.Scanner;

import com.yash.model.User;
import com.yash.service.UserService;
/**
 * This is a start up class for the application.
 * @author maithili.pande
 *
 */
public class StartUpApplication {

	public static void main(String[] args) {
		UserService service= new UserService();
		Scanner input = new Scanner(System.in);
		int choice;
		String continueChoice;
		do
		{
			System.out.println("Menu");
			System.out.println("1.Add User");
			System.out.println("2.List User");
			System.out.println("Enter your choice:");
			choice=input.nextInt();
			switch(choice)
			{
			case 1:
				User user= new User();
				System.out.println("Enter user id:");
				int uId= input.nextInt();
				user.setUserId(uId);
				System.out.println("Enter user name:");
				String uName= input.next();
				user.setName(uName);
				System.out.println("Enter user status:");
				String uStatus= input.next();
				user.setStatus(uStatus);
				service.addUser(user);
				
				break;
			case 2:
				List<User> userList=service.listUser();
				for(User usr:userList)
				{
					System.out.println(usr);
				}
				
				break;
			default:
				break;
			
			}
			System.out.println("Do you want to continue: (yes/no)");
			continueChoice=input.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
		input.close();
		

	}
	

}
