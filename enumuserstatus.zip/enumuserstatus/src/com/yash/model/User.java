package com.yash.model;

import com.yash.enumerator.UserStatus;
/**
 * This class initializes variables and sets their values. The status instance is set by enum.
 * @author maithili.pande
 *
 */
public class User {
	
	private int userId;
	private String name;
	private String status;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		if(status.equalsIgnoreCase("PENDING"))
		{
			UserStatus uStatus=UserStatus.PENDING;
			this.status=uStatus.status();
		}
		else if(status.equalsIgnoreCase("ACTIVE"))
		{
			UserStatus uStatus=UserStatus.ACTIVE;
			this.status=uStatus.status();
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			UserStatus uStatus=UserStatus.INACTIVE;
			this.status=uStatus.status();
		}
		else if(status.equalsIgnoreCase("DELETED"))
		{
			UserStatus uStatus=UserStatus.DELETED;
			this.status=uStatus.status();
		}
		
	}
	
	public User()
	{
	}
	
	public User(int userId, String name, String status) {
		this.userId = userId;
		this.name = name;
		this.status = status;
	}
	
	
	
	@Override
	public String toString() {
		return "[User Id:"+this.getUserId()+" User Name:"+this.getName()+" User Status:"+this.getStatus()+"]";
	}
	
	
	

}
