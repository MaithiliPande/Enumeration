package com.yash.enumerator;
/**
 * This is enumerator with name UserStatus which has fixed set of constants PENDING, ACTIVE, INACTIVE and DELETED.
 * @author maithili.pande
 *
 */
public enum UserStatus {
	PENDING("pending")
	{
		@Override
		public String status() {
			return "Pending";
		}
		
	},ACTIVE("active")
	{

		@Override
		public String status() {
			return "Active";
		}
		
	},INACTIVE("inactive")
	{

		@Override
		public String status() {
			return "Inactive";
		}
		
	},DELETED("deleted")
	{

		@Override
		public String status() {
			return "Deleted";
		}
		
	};

	private String user;
	
	private UserStatus(String u)
	{
		this.user=u;
	}
	
	public abstract String status();
	
}
