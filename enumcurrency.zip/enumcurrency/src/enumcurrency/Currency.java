package enumcurrency;

public enum Currency {
	PENNY(1)
	{
		@Override
		public String color() {
			return "Copper";
		}
	},NICKLE(5)
	{
		@Override
		public String color() {
			return "Bronze";
		}
	},DIME(10)
	{
		@Override
		public String color() {
			return "Silver";
		}
	},QUARTER(25)
	{
		@Override
		public String color() {
			return "Silver";
		}
	};
	private int value;
	private Currency (int val)
	{
		this.value=val;
	}
	public abstract String color();
	@Override
	public String toString() {
		switch(this)
		{
		case PENNY:
			return "Penny coin"+" value: "+value+" Color: "+ color();
//			System.out.println("Penny coin"+" value: "+value);
//			break;
		case NICKLE:
			return "Nickle coin"+" value: "+value+" Color: "+ color();
//			System.out.println("Nickle coin"+" value: "+value);
//			break;
		case DIME:
			return "Dime coin"+" value: "+value+" Color: "+ color();
//			System.out.println("Dime coin"+" value: "+value);
//			break;
		case QUARTER:
			return "Quarter coin"+" value:"+value+" color:"+ color();
//			System.out.println("Quarter coin"+" value: "+value);
//			break;
		default:
			System.out.println("Invalid input");
			break;
		}
		return null;
		
	}
	public int getValue()
	{
		int value=this.value;
		return value;
		
	}

}
