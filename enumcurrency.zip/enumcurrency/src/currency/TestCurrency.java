package currency;

import enumcurrency.Currency;

public class TestCurrency {

	public static void main(String[] args) {
		Currency usCoin= Currency.NICKLE;
		
		System.out.println(usCoin);
//		for(Currency coin: Currency.values())
//		{
//			System.out.println("Coin: "+coin+coin.ordinal());
//		}
System.out.println(usCoin.getValue());
	}

}
